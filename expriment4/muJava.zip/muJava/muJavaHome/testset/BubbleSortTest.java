import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class BubbleSortTest{
	
	@Test
	public void testConstructor(){
		BubbleSort bst=new BubbleSort();
		int arr[] = new int[]{1,6,2,2,5};
		int right[]=new int[]{1,2,2,5,6};
		assertEquals(right, bst.BubbleSort(arr));
	}
}